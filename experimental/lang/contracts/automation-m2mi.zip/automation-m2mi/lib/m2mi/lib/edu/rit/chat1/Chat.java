//******************************************************************************
//
// File:    Chat.java
// Package: edu.rit.chat1
// Unit:    Class edu.rit.chat1.Chat
//
// This Java source file is copyright (C) 2006 by Alan Kaminsky. All rights
// reserved. For further information, contact the author, Alan Kaminsky, at
// ark@cs.rit.edu.
//
// This Java source file is part of the M2MI Library ("The Library"). The
// Library is free software; you can redistribute it and/or modify it under the
// terms of the GNU General Public License as published by the Free Software
// Foundation; either version 2 of the License, or (at your option) any later
// version.
//
// The Library is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
// FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
// details.
//
// A copy of the GNU General Public License is provided in the file gpl.txt. You
// may also obtain a copy of the GNU General Public License on the World Wide
// Web at http://www.gnu.org/licenses/gpl.html or by writing to the Free
// Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
// USA.
//
//******************************************************************************

package edu.rit.chat1;

import edu.rit.m2mi.InvocationException;
import edu.rit.m2mi.M2MI;

import edu.rit.util.Transcript;

import java.io.PrintStream;

/**
 * Class Chat is a rudimentary M2MI-based chat application. The program displays
 * a simple chat UI (an instance of class {@link ChatFrame
 * </CODE>ChatFrame<CODE>}), and the program exports a chat object (an instance
 * of class Chat) that implements interface {@link ChatRef
 * </CODE>ChatRef<CODE>}. When the user sends a line of text in the UI, the line
 * is broadcast to all the chat objects by calling <TT>putLine()</TT> on an
 * omnihandle for interface ChatRef. When each chat object receives a
 * <TT>putLine()</TT> invocation, it displays the line of text in the chat log
 * in its UI. In this way the line of text appears in all the chat programs that
 * are running.
 * <P>
 * The chat demo is intended merely to demonstrate M2MI omnihandle invocations
 * and is not intended to be a full-featured chat application.
 * <P>
 * Usage: java edu.rit.chat1.Chat <I>username</I>
 * <P>
 * When running the chat demo application, M2MI and M2MP must be configured, and
 * the M2MP Daemon must be running if necessary. See packages {@linkplain
 * edu.rit.m2mi} and {@linkplain edu.rit.m2mp} for further information.
 * <P>
 * The chat demo application displays this UI:
 * <P>
 * <CENTER>
 * <IMG SRC="doc-files/chatui.png">
 * </CENTER>
 * <P>
 * Type a line of text into any chat window on any machine and hit return or
 * click the "Send" button. The line of text, prefixed by the user name, shows
 * up in all the chat windows on all the machines.
 *
 * @author  Alan Kaminsky
 * @version 26-Mar-2006
 */
public class Chat
	implements ChatRef, ChatFrameListener
	{

// Hidden data members.

	private String myUserName;
	private ChatFrame myChatFrame;
	private Transcript myChatLog;
	private PrintStream myChatLogStream;
	private ChatRef allChats;

// Hidden constructors.

	private Chat()
		{
		}

// Exported operations.

	/**
	 * Run this chat application.
	 *
	 * @param  args  Command line arguments.
	 */
	public void run
		(String[] args)
		throws Throwable
		{
		// Parse command line arguments.
		if (args.length != 1) usage();
		myUserName = args[0];

		// Initialize the M2MI Layer.
		M2MI.initialize();

		// Set up UI.
		myChatFrame = new ChatFrame ("M2MI Chat Demo 1 -- " + args[0]);
		myChatLog = myChatFrame.getChatLog();
		myChatLogStream = new PrintStream (myChatLog.getOutputStream());
		myChatFrame.setListener (this);

		// Export this chat object so it can receive M2MI invocations.
		M2MI.export (this, ChatRef.class);

		// Get an omnihandle for broadcasting M2MI invocations to all chat
		// objects.
		allChats = (ChatRef) M2MI.getOmnihandle (ChatRef.class);
		}

	/**
	 * Process the given line of text entered by the user.
	 *
	 * @param  line  Line of text.
	 */
	public void send
		(String line)
		{
		try
			{
			allChats.putMessage (myUserName + "> " + line);
			}
		catch (InvocationException exc)
			{
			exc.printStackTrace (System.err);
			}
		}

	/**
	 * Display the given line of text in this chat object's chat log.
	 *
	 * @param  line  Line of text.
	 */
	public void putMessage
		(String line)
		{
		myChatLogStream.println (line);
		}

// Hidden operations.

	/**
	 * Print a usage message and exit.
	 */
	private void usage()
		{
		System.err.println ("Usage: java edu.rit.chat1.Chat <username>");
		System.exit (1);
		}

// Main program.

	/**
	 * Main program.
	 *
	 * @param  args  Command line arguments.
	 */
	public static void main
		(String[] args)
		throws Throwable
		{
		new Chat().run (args);
		}

	}
